cp v2ray /etc/init.d/
cp -r ./soft/v2ray /usr/bin/
chmod a+x /etc/init.d/v2ray.sh
cp -rf config.json /etc/v2ray/config.json
service  v2ray start
mkdir /var/log/v2ray/
chkconfig  v2ray on
cp ./Caddyfile /root/ 
nohup ./caddy -agree=true -conf /root/Caddyfile >caddy.log 2>&1 &
cp -ru soft/caddy /root/
